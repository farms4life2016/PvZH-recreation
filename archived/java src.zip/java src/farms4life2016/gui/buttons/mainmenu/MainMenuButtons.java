package farms4life2016.gui.buttons.mainmenu;

import java.awt.Graphics2D;
import java.awt.event.MouseEvent;

import farms4life2016.gui.buttons.AbstractButton;

public class MainMenuButtons extends AbstractButton {

    /*
    Buttons required: 
    - play (multiplayer, join game or host)
    - collection
    - achivements
    - wiki?
    - github?
    - updates?
    - zen garden?
    */

    @Override
    public void onClick(MouseEvent e) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void drawSelf(Graphics2D g) {
        // TODO Auto-generated method stub
        
    }
    
}
